﻿Public Class About
    Private Sub weblb_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles weblb.LinkClicked
        Try
            Process.Start(VoicePad.GetDefaultBrowserPath(), "http://www.thesarktech.com")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub maillb_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles maillb.LinkClicked
        Try
            Process.Start("mailto:support@thesarktech.com")
        Catch ex As Exception

        End Try
    End Sub
End Class