﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class About
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(About))
        Me.imagepb = New System.Windows.Forms.PictureBox()
        Me.headinglb = New System.Windows.Forms.Label()
        Me.companylb = New System.Windows.Forms.Label()
        Me.prodlb = New System.Windows.Forms.Label()
        Me.versionlb = New System.Windows.Forms.Label()
        Me.copyrightlb = New System.Windows.Forms.Label()
        Me.weblb = New System.Windows.Forms.LinkLabel()
        Me.contactlb = New System.Windows.Forms.Label()
        Me.maillb = New System.Windows.Forms.LinkLabel()
        Me.publb = New System.Windows.Forms.Label()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        CType(Me.imagepb, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'imagepb
        '
        Me.imagepb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.imagepb.Image = Global.The_SARK_VoicePad.My.Resources.Resources.voicepad_image
        Me.imagepb.Location = New System.Drawing.Point(12, 67)
        Me.imagepb.Name = "imagepb"
        Me.imagepb.Size = New System.Drawing.Size(150, 123)
        Me.imagepb.TabIndex = 0
        Me.imagepb.TabStop = False
        '
        'headinglb
        '
        Me.headinglb.AutoSize = True
        Me.headinglb.Font = New System.Drawing.Font("Algerian", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.headinglb.Location = New System.Drawing.Point(121, 22)
        Me.headinglb.Name = "headinglb"
        Me.headinglb.Size = New System.Drawing.Size(194, 21)
        Me.headinglb.TabIndex = 1
        Me.headinglb.Text = "The SARK VoicePad"
        '
        'companylb
        '
        Me.companylb.AutoSize = True
        Me.companylb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.companylb.Location = New System.Drawing.Point(168, 161)
        Me.companylb.Name = "companylb"
        Me.companylb.Size = New System.Drawing.Size(250, 19)
        Me.companylb.TabIndex = 2
        Me.companylb.Text = "Company : The SARK Technologies"
        '
        'prodlb
        '
        Me.prodlb.AutoSize = True
        Me.prodlb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.prodlb.Location = New System.Drawing.Point(168, 63)
        Me.prodlb.Name = "prodlb"
        Me.prodlb.Size = New System.Drawing.Size(213, 19)
        Me.prodlb.TabIndex = 3
        Me.prodlb.Text = "Product : The SARK VoicePad"
        '
        'versionlb
        '
        Me.versionlb.AutoSize = True
        Me.versionlb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.versionlb.Location = New System.Drawing.Point(168, 95)
        Me.versionlb.Name = "versionlb"
        Me.versionlb.Size = New System.Drawing.Size(93, 19)
        Me.versionlb.TabIndex = 4
        Me.versionlb.Text = "Version : 1.0"
        '
        'copyrightlb
        '
        Me.copyrightlb.AutoSize = True
        Me.copyrightlb.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.copyrightlb.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.copyrightlb.ForeColor = System.Drawing.Color.Black
        Me.copyrightlb.Location = New System.Drawing.Point(13, 207)
        Me.copyrightlb.Name = "copyrightlb"
        Me.copyrightlb.Size = New System.Drawing.Size(481, 15)
        Me.copyrightlb.TabIndex = 5
        Me.copyrightlb.Text = "The SARK VoicePad Version 1.0 ©  2019 The SARK Technologies. All rights reserved." &
    ""
        '
        'weblb
        '
        Me.weblb.AutoSize = True
        Me.weblb.Location = New System.Drawing.Point(12, 263)
        Me.weblb.Name = "weblb"
        Me.weblb.Size = New System.Drawing.Size(194, 16)
        Me.weblb.TabIndex = 7
        Me.weblb.TabStop = True
        Me.weblb.Text = "http://www.thesarktech.com"
        '
        'contactlb
        '
        Me.contactlb.AutoSize = True
        Me.contactlb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.contactlb.Location = New System.Drawing.Point(12, 235)
        Me.contactlb.Name = "contactlb"
        Me.contactlb.Size = New System.Drawing.Size(152, 19)
        Me.contactlb.TabIndex = 8
        Me.contactlb.Text = "Contact Information :"
        '
        'maillb
        '
        Me.maillb.AutoSize = True
        Me.maillb.Location = New System.Drawing.Point(13, 288)
        Me.maillb.Name = "maillb"
        Me.maillb.Size = New System.Drawing.Size(188, 16)
        Me.maillb.TabIndex = 9
        Me.maillb.TabStop = True
        Me.maillb.Text = "support@thesarktech.com"
        '
        'publb
        '
        Me.publb.AutoSize = True
        Me.publb.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.publb.Location = New System.Drawing.Point(168, 130)
        Me.publb.Name = "publb"
        Me.publb.Size = New System.Drawing.Size(136, 19)
        Me.publb.TabIndex = 10
        Me.publb.Text = "Published In : 2019"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.RichTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox1.Cursor = System.Windows.Forms.Cursors.Default
        Me.RichTextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox1.Location = New System.Drawing.Point(12, 326)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.ReadOnly = True
        Me.RichTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox1.Size = New System.Drawing.Size(485, 70)
        Me.RichTextBox1.TabIndex = 11
        Me.RichTextBox1.Text = resources.GetString("RichTextBox1.Text")
        '
        'About
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(509, 411)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.publb)
        Me.Controls.Add(Me.maillb)
        Me.Controls.Add(Me.contactlb)
        Me.Controls.Add(Me.weblb)
        Me.Controls.Add(Me.copyrightlb)
        Me.Controls.Add(Me.versionlb)
        Me.Controls.Add(Me.prodlb)
        Me.Controls.Add(Me.companylb)
        Me.Controls.Add(Me.headinglb)
        Me.Controls.Add(Me.imagepb)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "About"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "About The SARK VoicePad"
        CType(Me.imagepb, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents imagepb As PictureBox
    Friend WithEvents headinglb As Label
    Friend WithEvents companylb As Label
    Friend WithEvents prodlb As Label
    Friend WithEvents versionlb As Label
    Friend WithEvents copyrightlb As Label
    Friend WithEvents weblb As LinkLabel
    Friend WithEvents contactlb As Label
    Friend WithEvents maillb As LinkLabel
    Friend WithEvents publb As Label
    Friend WithEvents RichTextBox1 As RichTextBox
End Class
