﻿Imports System.IO
Imports System.Speech

Public Class VoicePad

    Public file As String
    Private filetext As String = ""
    Private saved As Boolean = False
    Private res As DialogResult
    Private printtext As String = ""
    Private pwidth As Integer = 0
    Private pheight As Integer = 0
    Private rect As New Rectangle
    Private sz As New Size
    Private cfitted As Integer = 0
    Private lfitted As Integer = 0
    Private sformat As New StringFormat
    Private undone As Boolean = False
    Private dftext As DataFormats.Format = DataFormats.GetFormat(DataFormats.Text)
    Private farpl As FindAndReplace
    Public findtext As String = ""
    Public tindex As Integer = 0
    Public endoffile As Boolean = False
    Public dummy As Integer = 0
    Private fullscreenwin As Boolean = False
    Private statstripshow As Boolean = False
    Private defzoom As Single = Nothing
    Private WithEvents Narrator As New Synthesis.SpeechSynthesizer()
    Private listenactivated As Boolean = False
    Private WithEvents recognizer As Recognition.SpeechRecognitionEngine
    Private exitfromapp As Boolean = False
    Private brush As Brush

    Private Sub NewFile()
        If saved = False Then
            res = MessageBox.Show("Do you want to save the file ?", "The SARK VoicePad", MessageBoxButtons.YesNoCancel)
            If res = DialogResult.Yes Then
                SaveFile()
            ElseIf res = DialogResult.Cancel Then
                Exit Sub
            Else
            End If
        End If
        filetext = ""
        textbox.Text = filetext
        file = ""
        Me.Text = "The SARK VoicePad"
        saved = False
        undone = False
    End Sub

    Private Sub OpenFile()
        If saved = False Then
            res = MessageBox.Show("Do you want to save the file ?", "The SARK VoicePad", MessageBoxButtons.YesNoCancel)
            If res = DialogResult.Yes Then
                SaveFile()
            ElseIf res = DialogResult.Cancel Then
                Exit Sub
            Else
            End If
        End If
        opendialog.Filter = "Text Files|*.txt|All Files|*.*"
        opendialog.FileName = ""
        If opendialog.ShowDialog = DialogResult.OK Then
            file = opendialog.FileName
            filetext = My.Computer.FileSystem.ReadAllText(file)
            textbox.Text = filetext
            Me.Text = "The SARK VoicePad - " + Path.GetFileNameWithoutExtension(file)
            undone = False
            saved = True
        End If
    End Sub

    Private Sub SaveFile()
        savedialog.Filter = "Text Files|*.txt"
        savedialog.FileName = ""
        If file = "" Then
            If savedialog.ShowDialog = DialogResult.OK Then
                file = savedialog.FileName
                filetext = textbox.Text
                My.Computer.FileSystem.WriteAllText(file, filetext, False)
                Me.Text = "The SARK VoicePad - " + Path.GetFileNameWithoutExtension(file)
                saved = True
            End If
        Else
            filetext = textbox.Text
            My.Computer.FileSystem.WriteAllText(file, filetext, False)
            saved = True
        End If
    End Sub

    Private Sub PrintFile()
        If Path.GetFileNameWithoutExtension(file) IsNot "" Then
            printdoc.DocumentName = Path.GetFileNameWithoutExtension(file)
            If printdoc.DocumentName = "" Then
                printdoc.DocumentName = "newdoc"
            End If
        End If
        printdialog.Document = printdoc
        printdialog.PrinterSettings = printdoc.PrinterSettings

        If printdialog.ShowDialog() = DialogResult.OK Then
            printdoc.PrinterSettings = printdialog.PrinterSettings
            printdoc.PrintController = New System.Drawing.Printing.StandardPrintController()
            brush = New SolidBrush(textbox.ForeColor)
            printdoc.Print()
        End If
    End Sub

    Private Sub ExitApp()
        If saved = False Then
            res = MessageBox.Show("Do you want to save the file before exit ?", "The SARK VoicePad", MessageBoxButtons.YesNoCancel)
            If res = DialogResult.Yes Then
                SaveFile()
                If saved = True Then
                    Try
                        Narrator.Pause()
                        Narrator.Dispose()
                        recognizer.RecognizeAsyncCancel()
                        recognizer.SetInputToNull()
                        recognizer.UnloadAllGrammars()
                        recognizer.Dispose()
                    Catch ex As Exception

                    End Try
                    exitfromapp = True
                    Application.Exit()
                End If
            ElseIf res = DialogResult.No Then
                Try
                    Narrator.Pause()
                    Narrator.Dispose()
                    recognizer.RecognizeAsyncCancel()
                    recognizer.SetInputToNull()
                    recognizer.UnloadAllGrammars()
                    recognizer.Dispose()
                Catch ex As Exception

                End Try
                exitfromapp = True
                Application.Exit()
            Else
            End If
        Else
            Try
                Narrator.Pause()
                Narrator.Dispose()
                recognizer.RecognizeAsyncCancel()
                recognizer.SetInputToNull()
                recognizer.UnloadAllGrammars()
                recognizer.Dispose()
            Catch ex As Exception

            End Try
            exitfromapp = True
            Application.Exit()
        End If
    End Sub

    Private Sub SaveVoice()
        Narrator.SpeakAsyncCancelAll()
        savedialog.Filter = "Voice Files|*.wav"
        savedialog.FileName = ""
        If savedialog.ShowDialog = DialogResult.OK Then
            Narrator.SetOutputToWaveFile(savedialog.FileName)
            Narrator.SpeakAsync(textbox.Text)
            AddHandler Narrator.SpeakCompleted, AddressOf Narrator_SaveCompleted
            Me.Enabled = False
        End If
    End Sub

    Public Function GetDefaultBrowserPath() As String
        Dim key As String = "http\shell\open\command"
        Dim registryKey As Microsoft.Win32.RegistryKey = My.Computer.Registry.ClassesRoot.OpenSubKey(key, False)
        Return DirectCast(registryKey.GetValue(Nothing, Nothing), String).Split(""""c)(1)
    End Function

    Private Sub newfilemenu_Click(sender As Object, e As EventArgs) Handles newfilemenu.Click
        Try
            NewFile()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub openfilemenu_Click(sender As Object, e As EventArgs) Handles openfilemenu.Click
        Try
            OpenFile()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub savefilemenu_Click(sender As Object, e As EventArgs) Handles savefilemenu.Click
        Try
            SaveFile()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub exitfilemenu_Click(sender As Object, e As EventArgs) Handles exitfilemenu.Click
        Try
            ExitApp()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub textbox_TextChanged(sender As Object, e As EventArgs) Handles textbox.TextChanged
        Try
            saved = False
            undone = False
            statlab.Text = "Lines : " + textbox.Lines.Count.ToString() + " | Characters : " + textbox.TextLength.ToString() + " | Zoom : " + (textbox.ZoomFactor * 100).ToString() + "%"
        Catch ex As Exception

        End Try
    End Sub

    Private Sub textbox_MouseUp(sender As Object, e As MouseEventArgs) Handles textbox.MouseUp
        Try
            If e.Button = MouseButtons.Right Then
                ctxttmenu.Show(textbox, e.Location)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub printdoc_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles printdoc.PrintPage
        Try
            printtext = printtext.Substring(cfitted)
            sformat.Trimming = StringTrimming.Word
            rect = New Rectangle(New Point(pwidth, pheight), sz)
            e.Graphics.DrawString(printtext, textbox.Font, brush, rect, sformat)
            e.Graphics.MeasureString(printtext, textbox.Font, sz, sformat, cfitted, lfitted)
            If printtext.Substring(cfitted).Length > 0 Then
                e.HasMorePages = True
            Else
                cfitted = 0
                lfitted = 0
                e.HasMorePages = False
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub undoeditmenu_Click(sender As Object, e As EventArgs) Handles undoeditmenu.Click
        Try
            If undone = False Then
                If textbox.CanUndo Then
                    textbox.Undo()
                    undone = True
                End If
            Else
                If textbox.CanRedo Then
                    textbox.Redo()
                    undone = False
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub cuteditmenu_Click(sender As Object, e As EventArgs) Handles cuteditmenu.Click
        Try
            textbox.Cut()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub copyeditmenu_Click(sender As Object, e As EventArgs) Handles copyeditmenu.Click
        Try
            textbox.Copy()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub pasteeditmenu_Click(sender As Object, e As EventArgs) Handles pasteeditmenu.Click
        Try
            If textbox.CanPaste(dftext) Then
                textbox.Paste()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub deleteeditmenu_Click(sender As Object, e As EventArgs) Handles deleteeditmenu.Click
        Try
            If textbox.SelectedText.Length > 0 Then
                textbox.SelectedText = ""
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub searchgoogleeditmenu_Click(sender As Object, e As EventArgs) Handles searchgoogleeditmenu.Click
        Try
            Process.Start(GetDefaultBrowserPath(), "https://www.google.com/search?q=" + textbox.SelectedText)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub findreplaceeditmenu_Click(sender As Object, e As EventArgs) Handles findreplaceeditmenu.Click
        Try
            farpl = New FindAndReplace()
            farpl.Show(Me)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub textbox_Click(sender As Object, e As EventArgs) Handles textbox.Click
        Try
            dummy = farpl.findtb.TextLength
            If farpl.dirdradbut.Checked = True Then
                If textbox.SelectionStart = textbox.TextLength Then
                    endoffile = True
                Else
                    endoffile = False
                End If
            Else
                If textbox.SelectionStart = 0 Then
                    endoffile = True
                Else
                    endoffile = False
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub selectalleditmenu_Click(sender As Object, e As EventArgs) Handles selectalleditmenu.Click
        Try
            textbox.SelectAll()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub timedateeditmenu_Click(sender As Object, e As EventArgs) Handles timedateeditmenu.Click
        Try
            If textbox.SelectedText Is Nothing Then
                textbox.Text.Insert(textbox.SelectionStart, DateAndTime.Now.ToString)
            Else
                textbox.SelectedText = DateAndTime.Now.ToString
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub wordwrapformatmenu_Click(sender As Object, e As EventArgs) Handles wordwrapformatmenu.Click
        Try
            If textbox.WordWrap = True Then
                textbox.WordWrap = False
            Else
                textbox.WordWrap = True
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub fontformatmenu_Click(sender As Object, e As EventArgs) Handles fontformatmenu.Click
        Try
            fntdialog.Font = textbox.Font
            fntdialog.Color = textbox.ForeColor
            If fntdialog.ShowDialog = DialogResult.OK Then
                textbox.Font = fntdialog.Font
                textbox.ForeColor = fntdialog.Color
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub fullscreenviewmenu_Click(sender As Object, e As EventArgs) Handles fullscreenviewmenu.Click
        Try
            If fullscreenwin = False Then
                Me.WindowState = FormWindowState.Maximized
                Me.FormBorderStyle = FormBorderStyle.None
                fullscreenwin = True
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub normalviewmenu_Click(sender As Object, e As EventArgs) Handles normalviewmenu.Click
        Try
            If fullscreenwin = True Then
                Me.WindowState = FormWindowState.Normal
                Me.FormBorderStyle = FormBorderStyle.Sizable
                fullscreenwin = False
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub statusbarviewmenu_Click(sender As Object, e As EventArgs) Handles statusbarviewmenu.Click
        Try
            If statstripshow = False Then
                statstrip.Visible = True
                statstripshow = True
            Else
                statstrip.Visible = False
                statstripshow = False
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub zoominviewmenu_Click(sender As Object, e As EventArgs) Handles zoominviewmenu.Click
        Try
            If textbox.ZoomFactor = 1.5 * defzoom Then
                Exit Sub
            End If
            textbox.ZoomFactor = textbox.ZoomFactor + 0.25 * defzoom
            statlab.Text = "Lines : " + textbox.Lines.Count.ToString() + " | Characters : " + textbox.TextLength.ToString() + " | Zoom : " + (textbox.ZoomFactor * 100).ToString() + "%"
        Catch ex As Exception

        End Try
    End Sub

    Private Sub VoicePad_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Try
                file = My.Application.filename
                If file.Length > 0 Then
                    filetext = My.Computer.FileSystem.ReadAllText(file)
                    textbox.Text = filetext
                    Me.Text = "The SARK VoicePad - " + Path.GetFileNameWithoutExtension(file)
                    undone = False
                    saved = True
                End If
            Catch ex As Exception
            End Try
            defzoom = textbox.ZoomFactor
                statlab.Text = "Lines : " + textbox.Lines.Count.ToString() + " | Characters : " + textbox.TextLength.ToString() + " | Zoom : " + (textbox.ZoomFactor * 100).ToString() + "%"
            Catch ex As Exception

            End Try
    End Sub

    Private Sub zoomoutviewmenu_Click(sender As Object, e As EventArgs) Handles zoomoutviewmenu.Click
        Try
            If textbox.ZoomFactor = 0.5 * defzoom Then
                Exit Sub
            End If
            textbox.ZoomFactor = textbox.ZoomFactor - 0.25 * defzoom
            statlab.Text = "Lines : " + textbox.Lines.Count.ToString() + " | Characters : " + textbox.TextLength.ToString() + " | Zoom : " + (textbox.ZoomFactor * 100).ToString() + "%"
        Catch ex As Exception

        End Try
    End Sub

    Private Sub zoomnorviewmenu_Click(sender As Object, e As EventArgs) Handles zoomnorviewmenu.Click
        Try
            textbox.ZoomFactor = defzoom
            statlab.Text = "Lines : " + textbox.Lines.Count.ToString() + " | Characters : " + textbox.TextLength.ToString() + " | Zoom : " + (textbox.ZoomFactor * 100).ToString() + "%"
        Catch ex As Exception

        End Try
    End Sub

    Private Sub viewhelpmenu_Click(sender As Object, e As EventArgs) Handles viewhelpmenu.Click
        Try
            Process.Start(GetDefaultBrowserPath(), "https://www.google.com/search?q=" + "Get Help With The SARK VoicePad")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub NewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewToolStripMenuItem.Click
        Try
            NewFile()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SaveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveToolStripMenuItem.Click
        Try
            SaveFile()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub UndoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UndoToolStripMenuItem.Click
        Try
            If undone = False Then
                If textbox.CanUndo Then
                    textbox.Undo()
                    undone = True
                End If
            Else
                If textbox.CanRedo Then
                    textbox.Redo()
                    undone = False
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub CutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CutToolStripMenuItem.Click
        Try
            textbox.Cut()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub CopyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyToolStripMenuItem.Click
        Try
            textbox.Copy()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub PasteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PasteToolStripMenuItem.Click
        Try
            If textbox.CanPaste(dftext) Then
                textbox.Paste()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SelectAllToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SelectAllToolStripMenuItem.Click
        Try
            textbox.SelectAll()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub PrintToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrintToolStripMenuItem.Click
        Try
            pagesetdialog.PageSettings.Margins = New Printing.Margins(100, 100, 100, 100)
            If pagesetdialog.ShowDialog = DialogResult.OK Then
                printtext = textbox.Text
                printdoc.PrinterSettings = pagesetdialog.PrinterSettings
                printdoc.DefaultPageSettings = pagesetdialog.PageSettings
                If pagesetdialog.PageSettings.Landscape = False Then
                    sz = New Size(pagesetdialog.PageSettings.PaperSize.Width, pagesetdialog.PageSettings.PaperSize.Height)
                Else
                    sz = New Size(pagesetdialog.PageSettings.PaperSize.Height, pagesetdialog.PageSettings.PaperSize.Width)
                End If
                PrintFile()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SearchToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchToolStripMenuItem.Click
        Try
            Process.Start(GetDefaultBrowserPath(), "https://www.google.com/search?q=" + textbox.SelectedText)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub FontToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FontToolStripMenuItem.Click
        Try
            fntdialog.Font = textbox.Font
            fntdialog.Color = textbox.ForeColor
            If fntdialog.ShowDialog = DialogResult.OK Then
                textbox.Font = fntdialog.Font
                textbox.ForeColor = fntdialog.Color
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub printfilemenu_Click(sender As Object, e As EventArgs) Handles printfilemenu.Click
        Try
            pagesetdialog.PageSettings.Margins = New Printing.Margins(100, 100, 100, 100)
            If pagesetdialog.ShowDialog = DialogResult.OK Then
                printtext = textbox.Text
                printdoc.PrinterSettings = pagesetdialog.PrinterSettings
                printdoc.DefaultPageSettings = pagesetdialog.PageSettings
                If pagesetdialog.PageSettings.Landscape = False Then
                    sz = New Size(pagesetdialog.PageSettings.PaperSize.Width, pagesetdialog.PageSettings.PaperSize.Height)
                Else
                    sz = New Size(pagesetdialog.PageSettings.PaperSize.Height, pagesetdialog.PageSettings.PaperSize.Width)
                End If
                PrintFile()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub VoicePad_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Try
            If saved = False Then
                If exitfromapp = False Then
                    res = MessageBox.Show("Do you want to save the file before exit ?", "The SARK VoicePad", MessageBoxButtons.YesNoCancel)
                    If res = DialogResult.Yes Then
                        If saved = False Then
                            SaveFile()
                            If saved = True Then
                                Try
                                    Narrator.Pause()
                                    Narrator.Dispose()
                                    recognizer.RecognizeAsyncCancel()
                                    recognizer.SetInputToNull()
                                    recognizer.UnloadAllGrammars()
                                    recognizer.Dispose()
                                Catch ex As Exception

                                End Try
                            Else
                                e.Cancel = True
                            End If
                        End If
                    ElseIf res = DialogResult.No Then
                        Try
                            Narrator.Pause()
                            Narrator.Dispose()
                            recognizer.RecognizeAsyncCancel()
                            recognizer.SetInputToNull()
                            recognizer.UnloadAllGrammars()
                            recognizer.Dispose()
                        Catch ex As Exception

                        End Try
                    Else
                        e.Cancel = True
                    End If
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub readallvoicemenu_Click(sender As Object, e As EventArgs) Handles readallvoicemenu.Click
        Try
            Narrator.SetOutputToDefaultAudioDevice()
            Narrator.SpeakAsyncCancelAll()
            Narrator.SpeakAsync(textbox.Text)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub readselvoicemenu_Click(sender As Object, e As EventArgs) Handles readselvoicemenu.Click
        Try
            Narrator.SetOutputToDefaultAudioDevice()
            Narrator.SpeakAsyncCancelAll()
            Narrator.SpeakAsync(textbox.SelectedText)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub saveasvoicemenu_Click(sender As Object, e As EventArgs) Handles saveasvoicemenu.Click
        Try
            SaveVoice()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Narrator_SaveCompleted(sender As Object, e As Synthesis.SpeakCompletedEventArgs) Handles Narrator.SpeakCompleted
        Try
            Narrator.SetOutputToNull()
            Me.Enabled = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub stopreadvoicemenu_Click(sender As Object, e As EventArgs) Handles stopreadvoicemenu.Click
        Try
            Narrator.SpeakAsyncCancelAll()
            Narrator.SetOutputToNull()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub listenactivatevoicemenu_Click(sender As Object, e As EventArgs) Handles listenactivatevoicemenu.Click
        Try
            If listenactivated = False Then
                recognizer = New Recognition.SpeechRecognitionEngine()
                listenactivatevoicemenu.Text = "Deactivate"
                listenwritevoicemenu.Enabled = True
                listenactivated = True
            Else
                recognizer.RecognizeAsyncCancel()
                recognizer.SetInputToNull()
                recognizer.UnloadAllGrammars()
                recognizer.Dispose()
                listenactivatevoicemenu.Text = "Activate"
                listenwritevoicemenu.Enabled = False
                listenactivated = False
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub listenwritevoicemenu_Click(sender As Object, e As EventArgs) Handles listenwritevoicemenu.Click
        Try
            recognizer.LoadGrammar(New Recognition.DictationGrammar)
            recognizer.SetInputToDefaultAudioDevice()
            recognizer.RecognizeAsync(Recognition.RecognizeMode.Multiple)
            listenwritevoicemenu.Enabled = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub listener_SpeechRecognized(sender As Object, e As Recognition.SpeechRecognizedEventArgs) Handles recognizer.SpeechRecognized
        Try
            textbox.AppendText(e.Result.Text)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ReadToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ReadToolStripMenuItem.Click
        Try
            Narrator.SetOutputToDefaultAudioDevice()
            Narrator.SpeakAsyncCancelAll()
            Narrator.SpeakAsync(textbox.Text)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub abouthelpmenu_Click(sender As Object, e As EventArgs) Handles abouthelpmenu.Click
        Try
            About.ShowDialog()
        Catch ex As Exception

        End Try
    End Sub
End Class
