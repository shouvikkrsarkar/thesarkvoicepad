﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class VoicePad
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(VoicePad))
        Me.menubar = New System.Windows.Forms.MenuStrip()
        Me.filemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.newfilemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.openfilemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.savefilemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.printfilemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.exitfilemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.editmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.undoeditmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.cuteditmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.copyeditmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.pasteeditmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.deleteeditmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.searchgoogleeditmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.findreplaceeditmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.selectalleditmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.timedateeditmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.formatmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.wordwrapformatmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.fontformatmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.voicemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.readallvoicemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.readselvoicemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.stopreadvoicemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.saveasvoicemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.listenvoicemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.listenactivatevoicemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.listenwritevoicemenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.viewmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.modeviewmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.fullscreenviewmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.normalviewmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.zoomviewmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.zoominviewmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.zoomoutviewmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.zoomnorviewmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.statusbarviewmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.helpmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.viewhelpmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.abouthelpmenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.textbox = New System.Windows.Forms.RichTextBox()
        Me.opendialog = New System.Windows.Forms.OpenFileDialog()
        Me.savedialog = New System.Windows.Forms.SaveFileDialog()
        Me.ctxttmenu = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.UndoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PasteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SelectAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.ReadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.PrintToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator()
        Me.SearchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FontToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.printdialog = New System.Windows.Forms.PrintDialog()
        Me.printdoc = New System.Drawing.Printing.PrintDocument()
        Me.pagesetdialog = New System.Windows.Forms.PageSetupDialog()
        Me.fntdialog = New System.Windows.Forms.FontDialog()
        Me.statstrip = New System.Windows.Forms.StatusStrip()
        Me.statlab = New System.Windows.Forms.ToolStripStatusLabel()
        Me.menubar.SuspendLayout()
        Me.ctxttmenu.SuspendLayout()
        Me.statstrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'menubar
        '
        Me.menubar.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.menubar.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.menubar.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.filemenu, Me.editmenu, Me.formatmenu, Me.voicemenu, Me.viewmenu, Me.helpmenu})
        Me.menubar.Location = New System.Drawing.Point(0, 0)
        Me.menubar.Name = "menubar"
        Me.menubar.Size = New System.Drawing.Size(534, 25)
        Me.menubar.TabIndex = 0
        '
        'filemenu
        '
        Me.filemenu.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.filemenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.newfilemenu, Me.openfilemenu, Me.savefilemenu, Me.printfilemenu, Me.ToolStripSeparator1, Me.exitfilemenu})
        Me.filemenu.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.filemenu.Name = "filemenu"
        Me.filemenu.Size = New System.Drawing.Size(40, 21)
        Me.filemenu.Text = "File"
        '
        'newfilemenu
        '
        Me.newfilemenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.New_48x48
        Me.newfilemenu.Name = "newfilemenu"
        Me.newfilemenu.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.newfilemenu.ShowShortcutKeys = False
        Me.newfilemenu.Size = New System.Drawing.Size(152, 22)
        Me.newfilemenu.Text = "New"
        '
        'openfilemenu
        '
        Me.openfilemenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Open_48x48
        Me.openfilemenu.Name = "openfilemenu"
        Me.openfilemenu.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.openfilemenu.ShowShortcutKeys = False
        Me.openfilemenu.Size = New System.Drawing.Size(152, 22)
        Me.openfilemenu.Text = "Open"
        '
        'savefilemenu
        '
        Me.savefilemenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Save_48x48
        Me.savefilemenu.Name = "savefilemenu"
        Me.savefilemenu.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.savefilemenu.ShowShortcutKeys = False
        Me.savefilemenu.Size = New System.Drawing.Size(152, 22)
        Me.savefilemenu.Text = "Save"
        '
        'printfilemenu
        '
        Me.printfilemenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Print_48x48
        Me.printfilemenu.Name = "printfilemenu"
        Me.printfilemenu.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.printfilemenu.ShowShortcutKeys = False
        Me.printfilemenu.Size = New System.Drawing.Size(152, 22)
        Me.printfilemenu.Text = "Print"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(149, 6)
        '
        'exitfilemenu
        '
        Me.exitfilemenu.Name = "exitfilemenu"
        Me.exitfilemenu.Size = New System.Drawing.Size(152, 22)
        Me.exitfilemenu.Text = "Exit"
        '
        'editmenu
        '
        Me.editmenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.undoeditmenu, Me.ToolStripSeparator2, Me.cuteditmenu, Me.copyeditmenu, Me.pasteeditmenu, Me.deleteeditmenu, Me.ToolStripSeparator3, Me.searchgoogleeditmenu, Me.ToolStripSeparator4, Me.findreplaceeditmenu, Me.ToolStripSeparator5, Me.selectalleditmenu, Me.timedateeditmenu})
        Me.editmenu.Name = "editmenu"
        Me.editmenu.Size = New System.Drawing.Size(43, 21)
        Me.editmenu.Text = "Edit"
        '
        'undoeditmenu
        '
        Me.undoeditmenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Undo_48x48
        Me.undoeditmenu.Name = "undoeditmenu"
        Me.undoeditmenu.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.undoeditmenu.ShowShortcutKeys = False
        Me.undoeditmenu.Size = New System.Drawing.Size(196, 22)
        Me.undoeditmenu.Text = "Undo / Redo"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(193, 6)
        '
        'cuteditmenu
        '
        Me.cuteditmenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Cut_48x48
        Me.cuteditmenu.Name = "cuteditmenu"
        Me.cuteditmenu.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.cuteditmenu.ShowShortcutKeys = False
        Me.cuteditmenu.Size = New System.Drawing.Size(196, 22)
        Me.cuteditmenu.Text = "Cut"
        '
        'copyeditmenu
        '
        Me.copyeditmenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Copy_48x48
        Me.copyeditmenu.Name = "copyeditmenu"
        Me.copyeditmenu.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.copyeditmenu.ShowShortcutKeys = False
        Me.copyeditmenu.Size = New System.Drawing.Size(196, 22)
        Me.copyeditmenu.Text = "Copy"
        '
        'pasteeditmenu
        '
        Me.pasteeditmenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Paste_48x48
        Me.pasteeditmenu.Name = "pasteeditmenu"
        Me.pasteeditmenu.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.pasteeditmenu.ShowShortcutKeys = False
        Me.pasteeditmenu.Size = New System.Drawing.Size(196, 22)
        Me.pasteeditmenu.Text = "Paste"
        '
        'deleteeditmenu
        '
        Me.deleteeditmenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Delete_48x48
        Me.deleteeditmenu.Name = "deleteeditmenu"
        Me.deleteeditmenu.ShowShortcutKeys = False
        Me.deleteeditmenu.Size = New System.Drawing.Size(196, 22)
        Me.deleteeditmenu.Text = "Delete"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(193, 6)
        '
        'searchgoogleeditmenu
        '
        Me.searchgoogleeditmenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Search_48x48
        Me.searchgoogleeditmenu.Name = "searchgoogleeditmenu"
        Me.searchgoogleeditmenu.Size = New System.Drawing.Size(196, 22)
        Me.searchgoogleeditmenu.Text = "Search With Google"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(193, 6)
        '
        'findreplaceeditmenu
        '
        Me.findreplaceeditmenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Find_48x48
        Me.findreplaceeditmenu.Name = "findreplaceeditmenu"
        Me.findreplaceeditmenu.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
        Me.findreplaceeditmenu.ShowShortcutKeys = False
        Me.findreplaceeditmenu.Size = New System.Drawing.Size(196, 22)
        Me.findreplaceeditmenu.Text = "Find And Replace"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(193, 6)
        '
        'selectalleditmenu
        '
        Me.selectalleditmenu.Name = "selectalleditmenu"
        Me.selectalleditmenu.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.selectalleditmenu.ShowShortcutKeys = False
        Me.selectalleditmenu.Size = New System.Drawing.Size(196, 22)
        Me.selectalleditmenu.Text = "Select All"
        '
        'timedateeditmenu
        '
        Me.timedateeditmenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Calendar_48x48
        Me.timedateeditmenu.Name = "timedateeditmenu"
        Me.timedateeditmenu.ShortcutKeys = System.Windows.Forms.Keys.F5
        Me.timedateeditmenu.ShowShortcutKeys = False
        Me.timedateeditmenu.Size = New System.Drawing.Size(196, 22)
        Me.timedateeditmenu.Text = "Time / Date"
        '
        'formatmenu
        '
        Me.formatmenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.wordwrapformatmenu, Me.ToolStripSeparator7, Me.fontformatmenu})
        Me.formatmenu.Name = "formatmenu"
        Me.formatmenu.Size = New System.Drawing.Size(64, 21)
        Me.formatmenu.Text = "Format"
        '
        'wordwrapformatmenu
        '
        Me.wordwrapformatmenu.Name = "wordwrapformatmenu"
        Me.wordwrapformatmenu.Size = New System.Drawing.Size(147, 22)
        Me.wordwrapformatmenu.Text = "Word Wrap"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(144, 6)
        '
        'fontformatmenu
        '
        Me.fontformatmenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Settings_48x48
        Me.fontformatmenu.Name = "fontformatmenu"
        Me.fontformatmenu.Size = New System.Drawing.Size(147, 22)
        Me.fontformatmenu.Text = "Font"
        '
        'voicemenu
        '
        Me.voicemenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.readallvoicemenu, Me.readselvoicemenu, Me.stopreadvoicemenu, Me.saveasvoicemenu, Me.ToolStripSeparator6, Me.listenvoicemenu})
        Me.voicemenu.Name = "voicemenu"
        Me.voicemenu.Size = New System.Drawing.Size(51, 21)
        Me.voicemenu.Text = "Voice"
        '
        'readallvoicemenu
        '
        Me.readallvoicemenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.voice_out
        Me.readallvoicemenu.Name = "readallvoicemenu"
        Me.readallvoicemenu.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.R), System.Windows.Forms.Keys)
        Me.readallvoicemenu.ShowShortcutKeys = False
        Me.readallvoicemenu.Size = New System.Drawing.Size(160, 22)
        Me.readallvoicemenu.Text = "Read All"
        '
        'readselvoicemenu
        '
        Me.readselvoicemenu.Name = "readselvoicemenu"
        Me.readselvoicemenu.Size = New System.Drawing.Size(160, 22)
        Me.readselvoicemenu.Text = "Read Selected"
        '
        'stopreadvoicemenu
        '
        Me.stopreadvoicemenu.Name = "stopreadvoicemenu"
        Me.stopreadvoicemenu.Size = New System.Drawing.Size(160, 22)
        Me.stopreadvoicemenu.Text = "Stop Reading"
        '
        'saveasvoicemenu
        '
        Me.saveasvoicemenu.Name = "saveasvoicemenu"
        Me.saveasvoicemenu.Size = New System.Drawing.Size(160, 22)
        Me.saveasvoicemenu.Text = "Save As Voice"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(157, 6)
        '
        'listenvoicemenu
        '
        Me.listenvoicemenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.listenactivatevoicemenu, Me.listenwritevoicemenu})
        Me.listenvoicemenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.voice_in
        Me.listenvoicemenu.Name = "listenvoicemenu"
        Me.listenvoicemenu.Size = New System.Drawing.Size(160, 22)
        Me.listenvoicemenu.Text = "Listen"
        '
        'listenactivatevoicemenu
        '
        Me.listenactivatevoicemenu.Name = "listenactivatevoicemenu"
        Me.listenactivatevoicemenu.Size = New System.Drawing.Size(177, 22)
        Me.listenactivatevoicemenu.Text = "Activate"
        '
        'listenwritevoicemenu
        '
        Me.listenwritevoicemenu.Enabled = False
        Me.listenwritevoicemenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.voice_in
        Me.listenwritevoicemenu.Name = "listenwritevoicemenu"
        Me.listenwritevoicemenu.Size = New System.Drawing.Size(177, 22)
        Me.listenwritevoicemenu.Text = "Listen And Write"
        '
        'viewmenu
        '
        Me.viewmenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.modeviewmenu, Me.zoomviewmenu, Me.statusbarviewmenu})
        Me.viewmenu.Name = "viewmenu"
        Me.viewmenu.Size = New System.Drawing.Size(48, 21)
        Me.viewmenu.Text = "View"
        '
        'modeviewmenu
        '
        Me.modeviewmenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.fullscreenviewmenu, Me.normalviewmenu})
        Me.modeviewmenu.Name = "modeviewmenu"
        Me.modeviewmenu.Size = New System.Drawing.Size(138, 22)
        Me.modeviewmenu.Text = "Mode"
        '
        'fullscreenviewmenu
        '
        Me.fullscreenviewmenu.Name = "fullscreenviewmenu"
        Me.fullscreenviewmenu.Size = New System.Drawing.Size(141, 22)
        Me.fullscreenviewmenu.Text = "Full Screen"
        '
        'normalviewmenu
        '
        Me.normalviewmenu.Name = "normalviewmenu"
        Me.normalviewmenu.Size = New System.Drawing.Size(141, 22)
        Me.normalviewmenu.Text = "Normal"
        '
        'zoomviewmenu
        '
        Me.zoomviewmenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.zoominviewmenu, Me.zoomoutviewmenu, Me.zoomnorviewmenu})
        Me.zoomviewmenu.Name = "zoomviewmenu"
        Me.zoomviewmenu.Size = New System.Drawing.Size(138, 22)
        Me.zoomviewmenu.Text = "Zoom"
        '
        'zoominviewmenu
        '
        Me.zoominviewmenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Zoom_In_48x48
        Me.zoominviewmenu.Name = "zoominviewmenu"
        Me.zoominviewmenu.Size = New System.Drawing.Size(139, 22)
        Me.zoominviewmenu.Text = "Zoom In"
        '
        'zoomoutviewmenu
        '
        Me.zoomoutviewmenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Zoom_Out_48x48
        Me.zoomoutviewmenu.Name = "zoomoutviewmenu"
        Me.zoomoutviewmenu.Size = New System.Drawing.Size(139, 22)
        Me.zoomoutviewmenu.Text = "Zoom Out"
        '
        'zoomnorviewmenu
        '
        Me.zoomnorviewmenu.Name = "zoomnorviewmenu"
        Me.zoomnorviewmenu.Size = New System.Drawing.Size(139, 22)
        Me.zoomnorviewmenu.Text = "Normal"
        '
        'statusbarviewmenu
        '
        Me.statusbarviewmenu.Name = "statusbarviewmenu"
        Me.statusbarviewmenu.Size = New System.Drawing.Size(138, 22)
        Me.statusbarviewmenu.Text = "Status Bar"
        '
        'helpmenu
        '
        Me.helpmenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.viewhelpmenu, Me.abouthelpmenu})
        Me.helpmenu.Name = "helpmenu"
        Me.helpmenu.Size = New System.Drawing.Size(48, 21)
        Me.helpmenu.Text = "Help"
        '
        'viewhelpmenu
        '
        Me.viewhelpmenu.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Help_48x48
        Me.viewhelpmenu.Name = "viewhelpmenu"
        Me.viewhelpmenu.Size = New System.Drawing.Size(136, 22)
        Me.viewhelpmenu.Text = "View Help"
        '
        'abouthelpmenu
        '
        Me.abouthelpmenu.Name = "abouthelpmenu"
        Me.abouthelpmenu.Size = New System.Drawing.Size(136, 22)
        Me.abouthelpmenu.Text = "About"
        '
        'textbox
        '
        Me.textbox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.textbox.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.textbox.Location = New System.Drawing.Point(0, 25)
        Me.textbox.Name = "textbox"
        Me.textbox.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical
        Me.textbox.Size = New System.Drawing.Size(534, 486)
        Me.textbox.TabIndex = 1
        Me.textbox.Text = ""
        Me.textbox.WordWrap = False
        '
        'opendialog
        '
        Me.opendialog.FileName = "OpenFileDialog1"
        '
        'ctxttmenu
        '
        Me.ctxttmenu.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ctxttmenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem, Me.ToolStripSeparator12, Me.SaveToolStripMenuItem, Me.ToolStripSeparator8, Me.UndoToolStripMenuItem, Me.CutToolStripMenuItem, Me.CopyToolStripMenuItem, Me.PasteToolStripMenuItem, Me.SelectAllToolStripMenuItem, Me.ToolStripSeparator9, Me.ReadToolStripMenuItem, Me.ToolStripSeparator10, Me.PrintToolStripMenuItem, Me.ToolStripSeparator11, Me.SearchToolStripMenuItem, Me.FontToolStripMenuItem})
        Me.ctxttmenu.Name = "contextmenu"
        Me.ctxttmenu.Size = New System.Drawing.Size(154, 276)
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.Image = Global.The_SARK_VoicePad.My.Resources.Resources.New_48x48
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.NewToolStripMenuItem.Text = "New"
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(150, 6)
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Save_48x48
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.SaveToolStripMenuItem.Text = "Save"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(150, 6)
        '
        'UndoToolStripMenuItem
        '
        Me.UndoToolStripMenuItem.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Undo_48x48
        Me.UndoToolStripMenuItem.Name = "UndoToolStripMenuItem"
        Me.UndoToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.UndoToolStripMenuItem.Text = "Undo / Redo"
        '
        'CutToolStripMenuItem
        '
        Me.CutToolStripMenuItem.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Cut_48x48
        Me.CutToolStripMenuItem.Name = "CutToolStripMenuItem"
        Me.CutToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.CutToolStripMenuItem.Text = "Cut"
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Copy_48x48
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.CopyToolStripMenuItem.Text = "Copy"
        '
        'PasteToolStripMenuItem
        '
        Me.PasteToolStripMenuItem.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Paste_48x48
        Me.PasteToolStripMenuItem.Name = "PasteToolStripMenuItem"
        Me.PasteToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.PasteToolStripMenuItem.Text = "Paste"
        '
        'SelectAllToolStripMenuItem
        '
        Me.SelectAllToolStripMenuItem.Name = "SelectAllToolStripMenuItem"
        Me.SelectAllToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.SelectAllToolStripMenuItem.Text = "Select All"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(150, 6)
        '
        'ReadToolStripMenuItem
        '
        Me.ReadToolStripMenuItem.Image = Global.The_SARK_VoicePad.My.Resources.Resources.voice_out
        Me.ReadToolStripMenuItem.Name = "ReadToolStripMenuItem"
        Me.ReadToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.ReadToolStripMenuItem.Text = "Read"
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(150, 6)
        '
        'PrintToolStripMenuItem
        '
        Me.PrintToolStripMenuItem.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Print_48x48
        Me.PrintToolStripMenuItem.Name = "PrintToolStripMenuItem"
        Me.PrintToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.PrintToolStripMenuItem.Text = "Print"
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(150, 6)
        '
        'SearchToolStripMenuItem
        '
        Me.SearchToolStripMenuItem.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Search_48x48
        Me.SearchToolStripMenuItem.Name = "SearchToolStripMenuItem"
        Me.SearchToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.SearchToolStripMenuItem.Text = "Search"
        '
        'FontToolStripMenuItem
        '
        Me.FontToolStripMenuItem.Image = Global.The_SARK_VoicePad.My.Resources.Resources.Settings_48x48
        Me.FontToolStripMenuItem.Name = "FontToolStripMenuItem"
        Me.FontToolStripMenuItem.Size = New System.Drawing.Size(153, 22)
        Me.FontToolStripMenuItem.Text = "Font"
        '
        'printdialog
        '
        Me.printdialog.Document = Me.printdoc
        Me.printdialog.UseEXDialog = True
        '
        'printdoc
        '
        Me.printdoc.DocumentName = "newdoc"
        '
        'pagesetdialog
        '
        Me.pagesetdialog.Document = Me.printdoc
        '
        'fntdialog
        '
        Me.fntdialog.ShowColor = True
        '
        'statstrip
        '
        Me.statstrip.Enabled = False
        Me.statstrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.statlab})
        Me.statstrip.Location = New System.Drawing.Point(0, 339)
        Me.statstrip.Name = "statstrip"
        Me.statstrip.Size = New System.Drawing.Size(384, 22)
        Me.statstrip.TabIndex = 2
        Me.statstrip.Visible = False
        '
        'statlab
        '
        Me.statlab.Name = "statlab"
        Me.statlab.Size = New System.Drawing.Size(119, 17)
        Me.statlab.Text = "ToolStripStatusLabel1"
        '
        'VoicePad
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(534, 511)
        Me.Controls.Add(Me.textbox)
        Me.Controls.Add(Me.statstrip)
        Me.Controls.Add(Me.menubar)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.menubar
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MinimumSize = New System.Drawing.Size(550, 550)
        Me.Name = "VoicePad"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "The SARK VoicePad"
        Me.menubar.ResumeLayout(False)
        Me.menubar.PerformLayout()
        Me.ctxttmenu.ResumeLayout(False)
        Me.statstrip.ResumeLayout(False)
        Me.statstrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents menubar As MenuStrip
    Friend WithEvents textbox As RichTextBox
    Friend WithEvents filemenu As ToolStripMenuItem
    Friend WithEvents newfilemenu As ToolStripMenuItem
    Friend WithEvents openfilemenu As ToolStripMenuItem
    Friend WithEvents savefilemenu As ToolStripMenuItem
    Friend WithEvents printfilemenu As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents exitfilemenu As ToolStripMenuItem
    Friend WithEvents editmenu As ToolStripMenuItem
    Friend WithEvents undoeditmenu As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents cuteditmenu As ToolStripMenuItem
    Friend WithEvents copyeditmenu As ToolStripMenuItem
    Friend WithEvents pasteeditmenu As ToolStripMenuItem
    Friend WithEvents deleteeditmenu As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents searchgoogleeditmenu As ToolStripMenuItem
    Friend WithEvents findreplaceeditmenu As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator5 As ToolStripSeparator
    Friend WithEvents selectalleditmenu As ToolStripMenuItem
    Friend WithEvents timedateeditmenu As ToolStripMenuItem
    Friend WithEvents formatmenu As ToolStripMenuItem
    Friend WithEvents wordwrapformatmenu As ToolStripMenuItem
    Friend WithEvents fontformatmenu As ToolStripMenuItem
    Friend WithEvents viewmenu As ToolStripMenuItem
    Friend WithEvents modeviewmenu As ToolStripMenuItem
    Friend WithEvents fullscreenviewmenu As ToolStripMenuItem
    Friend WithEvents normalviewmenu As ToolStripMenuItem
    Friend WithEvents statusbarviewmenu As ToolStripMenuItem
    Friend WithEvents voicemenu As ToolStripMenuItem
    Friend WithEvents readallvoicemenu As ToolStripMenuItem
    Friend WithEvents readselvoicemenu As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As ToolStripSeparator
    Friend WithEvents listenvoicemenu As ToolStripMenuItem
    Friend WithEvents listenactivatevoicemenu As ToolStripMenuItem
    Friend WithEvents listenwritevoicemenu As ToolStripMenuItem
    Friend WithEvents helpmenu As ToolStripMenuItem
    Friend WithEvents viewhelpmenu As ToolStripMenuItem
    Friend WithEvents abouthelpmenu As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As ToolStripSeparator
    Friend WithEvents opendialog As OpenFileDialog
    Friend WithEvents savedialog As SaveFileDialog
    Friend WithEvents ctxttmenu As ContextMenuStrip
    Friend WithEvents NewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UndoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PasteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReadToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PrintToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator12 As ToolStripSeparator
    Friend WithEvents SaveToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As ToolStripSeparator
    Friend WithEvents SelectAllToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator9 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator10 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator11 As ToolStripSeparator
    Friend WithEvents SearchToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FontToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents printdialog As PrintDialog
    Friend WithEvents printdoc As Printing.PrintDocument
    Friend WithEvents pagesetdialog As PageSetupDialog
    Friend WithEvents fntdialog As FontDialog
    Friend WithEvents statstrip As StatusStrip
    Friend WithEvents zoomviewmenu As ToolStripMenuItem
    Friend WithEvents zoominviewmenu As ToolStripMenuItem
    Friend WithEvents zoomoutviewmenu As ToolStripMenuItem
    Friend WithEvents zoomnorviewmenu As ToolStripMenuItem
    Friend WithEvents statlab As ToolStripStatusLabel
    Friend WithEvents saveasvoicemenu As ToolStripMenuItem
    Friend WithEvents stopreadvoicemenu As ToolStripMenuItem
End Class
