﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FindAndReplace
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FindAndReplace))
        Me.findnbut = New System.Windows.Forms.Button()
        Me.findlab = New System.Windows.Forms.Label()
        Me.findtb = New System.Windows.Forms.TextBox()
        Me.diruradbut = New System.Windows.Forms.RadioButton()
        Me.dirdradbut = New System.Windows.Forms.RadioButton()
        Me.dirlab = New System.Windows.Forms.Label()
        Me.mcasecb = New System.Windows.Forms.CheckBox()
        Me.waroundcb = New System.Windows.Forms.CheckBox()
        Me.cancelbut = New System.Windows.Forms.Button()
        Me.repltb = New System.Windows.Forms.TextBox()
        Me.repllab = New System.Windows.Forms.Label()
        Me.replbut = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'findnbut
        '
        Me.findnbut.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.findnbut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.findnbut.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.findnbut.Location = New System.Drawing.Point(250, 12)
        Me.findnbut.Name = "findnbut"
        Me.findnbut.Size = New System.Drawing.Size(82, 25)
        Me.findnbut.TabIndex = 0
        Me.findnbut.Text = "Find Next"
        Me.findnbut.UseVisualStyleBackColor = True
        '
        'findlab
        '
        Me.findlab.AutoSize = True
        Me.findlab.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.findlab.Location = New System.Drawing.Point(19, 19)
        Me.findlab.Name = "findlab"
        Me.findlab.Size = New System.Drawing.Size(68, 15)
        Me.findlab.TabIndex = 2
        Me.findlab.Text = "Find What :"
        '
        'findtb
        '
        Me.findtb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.findtb.Location = New System.Drawing.Point(93, 16)
        Me.findtb.Name = "findtb"
        Me.findtb.Size = New System.Drawing.Size(151, 21)
        Me.findtb.TabIndex = 3
        '
        'diruradbut
        '
        Me.diruradbut.AutoSize = True
        Me.diruradbut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.diruradbut.Location = New System.Drawing.Point(196, 89)
        Me.diruradbut.Name = "diruradbut"
        Me.diruradbut.Size = New System.Drawing.Size(38, 17)
        Me.diruradbut.TabIndex = 4
        Me.diruradbut.Text = "Up"
        Me.diruradbut.UseVisualStyleBackColor = True
        '
        'dirdradbut
        '
        Me.dirdradbut.AutoSize = True
        Me.dirdradbut.Checked = True
        Me.dirdradbut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.dirdradbut.Location = New System.Drawing.Point(240, 89)
        Me.dirdradbut.Name = "dirdradbut"
        Me.dirdradbut.Size = New System.Drawing.Size(52, 17)
        Me.dirdradbut.TabIndex = 5
        Me.dirdradbut.TabStop = True
        Me.dirdradbut.Text = "Down"
        Me.dirdradbut.UseVisualStyleBackColor = True
        '
        'dirlab
        '
        Me.dirlab.AutoSize = True
        Me.dirlab.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dirlab.Location = New System.Drawing.Point(128, 89)
        Me.dirlab.Name = "dirlab"
        Me.dirlab.Size = New System.Drawing.Size(62, 15)
        Me.dirlab.TabIndex = 6
        Me.dirlab.Text = "Direction :"
        '
        'mcasecb
        '
        Me.mcasecb.AutoSize = True
        Me.mcasecb.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.mcasecb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mcasecb.Location = New System.Drawing.Point(12, 85)
        Me.mcasecb.Name = "mcasecb"
        Me.mcasecb.Size = New System.Drawing.Size(88, 19)
        Me.mcasecb.TabIndex = 7
        Me.mcasecb.Text = "Match Case"
        Me.mcasecb.UseVisualStyleBackColor = True
        '
        'waroundcb
        '
        Me.waroundcb.AutoSize = True
        Me.waroundcb.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.waroundcb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.waroundcb.Location = New System.Drawing.Point(12, 110)
        Me.waroundcb.Name = "waroundcb"
        Me.waroundcb.Size = New System.Drawing.Size(94, 19)
        Me.waroundcb.TabIndex = 8
        Me.waroundcb.Text = "Wrap Around"
        Me.waroundcb.UseVisualStyleBackColor = True
        '
        'cancelbut
        '
        Me.cancelbut.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cancelbut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cancelbut.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cancelbut.Location = New System.Drawing.Point(250, 117)
        Me.cancelbut.Name = "cancelbut"
        Me.cancelbut.Size = New System.Drawing.Size(82, 25)
        Me.cancelbut.TabIndex = 9
        Me.cancelbut.Text = "Cancel"
        Me.cancelbut.UseVisualStyleBackColor = True
        '
        'repltb
        '
        Me.repltb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.repltb.Location = New System.Drawing.Point(93, 47)
        Me.repltb.Name = "repltb"
        Me.repltb.Size = New System.Drawing.Size(151, 21)
        Me.repltb.TabIndex = 10
        '
        'repllab
        '
        Me.repllab.AutoSize = True
        Me.repllab.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.repllab.Location = New System.Drawing.Point(1, 50)
        Me.repllab.Name = "repllab"
        Me.repllab.Size = New System.Drawing.Size(86, 15)
        Me.repllab.TabIndex = 11
        Me.repllab.Text = "Replace With :"
        '
        'replbut
        '
        Me.replbut.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.replbut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.replbut.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.replbut.Location = New System.Drawing.Point(250, 43)
        Me.replbut.Name = "replbut"
        Me.replbut.Size = New System.Drawing.Size(82, 25)
        Me.replbut.TabIndex = 12
        Me.replbut.Text = "Replace"
        Me.replbut.UseVisualStyleBackColor = True
        '
        'FindAndReplace
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(334, 148)
        Me.Controls.Add(Me.replbut)
        Me.Controls.Add(Me.repllab)
        Me.Controls.Add(Me.repltb)
        Me.Controls.Add(Me.cancelbut)
        Me.Controls.Add(Me.waroundcb)
        Me.Controls.Add(Me.mcasecb)
        Me.Controls.Add(Me.dirlab)
        Me.Controls.Add(Me.dirdradbut)
        Me.Controls.Add(Me.diruradbut)
        Me.Controls.Add(Me.findtb)
        Me.Controls.Add(Me.findlab)
        Me.Controls.Add(Me.findnbut)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FindAndReplace"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Find And Replace"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents findnbut As Button
    Friend WithEvents findlab As Label
    Friend WithEvents findtb As TextBox
    Friend WithEvents diruradbut As RadioButton
    Friend WithEvents dirdradbut As RadioButton
    Friend WithEvents dirlab As Label
    Friend WithEvents mcasecb As CheckBox
    Friend WithEvents waroundcb As CheckBox
    Friend WithEvents cancelbut As Button
    Friend WithEvents repltb As TextBox
    Friend WithEvents repllab As Label
    Friend WithEvents replbut As Button
End Class
