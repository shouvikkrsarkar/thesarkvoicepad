﻿Public Class FindAndReplace

    Private Sub findnbut_Click(sender As Object, e As EventArgs) Handles findnbut.Click
        Try
            If waroundcb.Checked = False And mcasecb.Checked = False Then
                If dirdradbut.Checked = True Then
                    If VoicePad.endoffile = True Then
                        Exit Sub
                    End If
                    VoicePad.textbox.[Select](VoicePad.textbox.SelectionStart + VoicePad.findtext.Length - VoicePad.dummy, 0)
                    VoicePad.dummy = 0
                    VoicePad.findtext = findtb.Text
                    VoicePad.tindex = VoicePad.textbox.Find(VoicePad.findtext, VoicePad.textbox.SelectionStart, VoicePad.textbox.TextLength, RichTextBoxFinds.None)
                    If VoicePad.tindex = -1 Then
                        VoicePad.endoffile = True
                        Exit Sub
                    End If
                    VoicePad.textbox.[Select](VoicePad.tindex, VoicePad.findtext.Length)
                    VoicePad.textbox.Focus()
                    VoicePad.textbox.ScrollToCaret()
                    If (VoicePad.textbox.SelectionStart + VoicePad.findtext.Length = VoicePad.textbox.TextLength) Then
                        VoicePad.endoffile = True
                    End If
                Else
                    If VoicePad.endoffile = True Then
                        Exit Sub
                    End If
                    VoicePad.findtext = findtb.Text
                    VoicePad.tindex = VoicePad.textbox.Find(VoicePad.findtext, 0, VoicePad.textbox.SelectionStart, RichTextBoxFinds.Reverse)
                    If VoicePad.tindex = -1 Then
                        VoicePad.endoffile = True
                        Exit Sub
                    End If
                    VoicePad.textbox.[Select](VoicePad.tindex, VoicePad.findtext.Length)
                    VoicePad.textbox.Focus()
                    VoicePad.textbox.ScrollToCaret()
                    If (VoicePad.textbox.SelectionStart = 0) Then
                        VoicePad.endoffile = True
                    End If
                End If
            ElseIf waroundcb.Checked = True And mcasecb.Checked = False Then
                If dirdradbut.Checked = True Then
                    VoicePad.textbox.[Select](VoicePad.textbox.SelectionStart + VoicePad.findtext.Length - VoicePad.dummy, 0)
                    VoicePad.dummy = 0
                    VoicePad.findtext = findtb.Text
                    VoicePad.tindex = VoicePad.textbox.Find(VoicePad.findtext, VoicePad.textbox.SelectionStart, VoicePad.textbox.TextLength, RichTextBoxFinds.None)
                    If VoicePad.tindex = -1 Then
                        VoicePad.textbox.SelectionStart = 0
                        VoicePad.tindex = VoicePad.textbox.Find(VoicePad.findtext, VoicePad.textbox.SelectionStart, VoicePad.textbox.TextLength, RichTextBoxFinds.None)
                    End If
                    VoicePad.textbox.[Select](VoicePad.tindex, VoicePad.findtext.Length)
                    VoicePad.textbox.Focus()
                    VoicePad.textbox.ScrollToCaret()
                Else
                    VoicePad.findtext = findtb.Text
                    VoicePad.tindex = VoicePad.textbox.Find(VoicePad.findtext, 0, VoicePad.textbox.SelectionStart, RichTextBoxFinds.Reverse)
                    If VoicePad.tindex = -1 Then
                        VoicePad.textbox.SelectionStart = VoicePad.textbox.TextLength
                        VoicePad.tindex = VoicePad.textbox.Find(VoicePad.findtext, 0, VoicePad.textbox.SelectionStart, RichTextBoxFinds.Reverse)
                    End If
                    VoicePad.textbox.[Select](VoicePad.tindex, VoicePad.findtext.Length)
                    VoicePad.textbox.Focus()
                    VoicePad.textbox.ScrollToCaret()
                End If
            ElseIf waroundcb.Checked = False And mcasecb.Checked = True Then
                If dirdradbut.Checked = True Then
                    If VoicePad.endoffile = True Then
                        Exit Sub
                    End If
                    VoicePad.textbox.[Select](VoicePad.textbox.SelectionStart + VoicePad.findtext.Length - VoicePad.dummy, 0)
                    VoicePad.dummy = 0
                    VoicePad.findtext = findtb.Text
                    VoicePad.tindex = VoicePad.textbox.Find(VoicePad.findtext, VoicePad.textbox.SelectionStart, VoicePad.textbox.TextLength, RichTextBoxFinds.MatchCase)
                    If VoicePad.tindex = -1 Then
                        VoicePad.endoffile = True
                        Exit Sub
                    End If
                    VoicePad.textbox.[Select](VoicePad.tindex, VoicePad.findtext.Length)
                    VoicePad.textbox.Focus()
                    VoicePad.textbox.ScrollToCaret()
                    If (VoicePad.textbox.SelectionStart + VoicePad.findtext.Length = VoicePad.textbox.TextLength) Then
                        VoicePad.endoffile = True
                    End If
                Else
                    If VoicePad.endoffile = True Then
                        Exit Sub
                    End If
                    VoicePad.findtext = findtb.Text
                    VoicePad.tindex = VoicePad.textbox.Find(VoicePad.findtext, 0, VoicePad.textbox.SelectionStart, RichTextBoxFinds.Reverse Or RichTextBoxFinds.MatchCase)
                    If VoicePad.tindex = -1 Then
                        VoicePad.endoffile = True
                        Exit Sub
                    End If
                    VoicePad.textbox.[Select](VoicePad.tindex, VoicePad.findtext.Length)
                    VoicePad.textbox.Focus()
                    VoicePad.textbox.ScrollToCaret()
                    If (VoicePad.textbox.SelectionStart = 0) Then
                        VoicePad.endoffile = True
                    End If
                End If
            Else
                If dirdradbut.Checked = True Then
                    VoicePad.textbox.[Select](VoicePad.textbox.SelectionStart + VoicePad.findtext.Length - VoicePad.dummy, 0)
                    VoicePad.dummy = 0
                    VoicePad.findtext = findtb.Text
                    VoicePad.tindex = VoicePad.textbox.Find(VoicePad.findtext, VoicePad.textbox.SelectionStart, VoicePad.textbox.TextLength, RichTextBoxFinds.MatchCase)
                    If VoicePad.tindex = -1 Then
                        VoicePad.textbox.SelectionStart = 0
                        VoicePad.tindex = VoicePad.textbox.Find(VoicePad.findtext, VoicePad.textbox.SelectionStart, VoicePad.textbox.TextLength, RichTextBoxFinds.MatchCase)
                    End If
                    VoicePad.textbox.[Select](VoicePad.tindex, VoicePad.findtext.Length)
                    VoicePad.textbox.Focus()
                    VoicePad.textbox.ScrollToCaret()
                Else
                    VoicePad.findtext = findtb.Text
                    VoicePad.tindex = VoicePad.textbox.Find(VoicePad.findtext, 0, VoicePad.textbox.SelectionStart, RichTextBoxFinds.Reverse Or RichTextBoxFinds.MatchCase)
                    If VoicePad.tindex = -1 Then
                        VoicePad.textbox.SelectionStart = VoicePad.textbox.TextLength
                        VoicePad.tindex = VoicePad.textbox.Find(VoicePad.findtext, 0, VoicePad.textbox.SelectionStart, RichTextBoxFinds.Reverse Or RichTextBoxFinds.MatchCase)
                    End If
                    VoicePad.textbox.[Select](VoicePad.tindex, VoicePad.findtext.Length)
                    VoicePad.textbox.Focus()
                    VoicePad.textbox.ScrollToCaret()
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub FindAndReplace_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            findtb.Text = VoicePad.findtext
            VoicePad.findtext = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub dirdradbut_CheckedChanged(sender As Object, e As EventArgs) Handles dirdradbut.CheckedChanged
        Try
            If dirdradbut.Checked = True Then
                If VoicePad.tindex = -1 Or VoicePad.textbox.SelectionStart = 0 Then
                    VoicePad.endoffile = False
                    VoicePad.dummy = VoicePad.findtext.Length
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub diruradbut_CheckedChanged(sender As Object, e As EventArgs) Handles diruradbut.CheckedChanged
        Try
            If diruradbut.Checked = True Then
                If VoicePad.tindex = -1 Or VoicePad.textbox.SelectionStart = VoicePad.textbox.TextLength - VoicePad.findtext.Length Then
                    VoicePad.endoffile = False
                    VoicePad.textbox.SelectionStart = VoicePad.textbox.TextLength
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub replbut_Click(sender As Object, e As EventArgs) Handles replbut.Click
        Try
            If repltb.Text IsNot "" And VoicePad.textbox.SelectedText IsNot "" Then
                VoicePad.textbox.SelectedText = repltb.Text
                VoicePad.textbox.[Select](VoicePad.textbox.SelectionStart - repltb.TextLength, repltb.TextLength)
                VoicePad.textbox.Focus()
                VoicePad.textbox.ScrollToCaret()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub cancelbut_Click(sender As Object, e As EventArgs) Handles cancelbut.Click
        Try
            Me.Dispose()
        Catch ex As Exception

        End Try
    End Sub
End Class